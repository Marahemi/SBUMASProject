package massim.scenario.city.data.facilities;

import massim.scenario.city.data.Location;

/**
 * Dump facility in the City scenario.
 */
public class Dump extends Facility{

    public Dump(String name, Location location) {
        super(name, location);
    }
}
